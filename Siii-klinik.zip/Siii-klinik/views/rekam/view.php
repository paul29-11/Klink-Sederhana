<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/** @var yii\web\View $this */
/** @var app\models\Rekam $model */

$this->title = $model->id_rekam;
$this->params['breadcrumbs'][] = ['label' => 'Rekams', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="rekam-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id_rekam' => $model->id_rekam], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Delete', ['delete', 'id_rekam' => $model->id_rekam], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id_rekam',
            'tgl',
            'id_pasien',
            'keluahan',
            'id_dokter',
            'diagnosa',
            'id_obat',
            'id_ruang',
        ],
    ]) ?>

</div>
