<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/** @var yii\web\View $this */
/** @var app\models\RekamSearch $model */
/** @var yii\widgets\ActiveForm $form */
?>

<div class="rekam-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
        'options' => [
            'data-pjax' => 1
        ],
    ]); ?>

    <?= $form->field($model, 'id_rekam') ?>

    <?= $form->field($model, 'tgl') ?>

    <?= $form->field($model, 'id_pasien') ?>

    <?= $form->field($model, 'keluahan') ?>

    <?= $form->field($model, 'id_dokter') ?>

    <?php // echo $form->field($model, 'diagnosa') ?>

    <?php // echo $form->field($model, 'id_obat') ?>

    <?php // echo $form->field($model, 'id_ruang') ?>

    <div class="form-group">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::resetButton('Reset', ['class' => 'btn btn-outline-secondary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
