<?php

use yii\helpers\Html;

/** @var yii\web\View $this */
/** @var app\models\Rekam $model */

$this->title = 'Update Rekam: ' . $model->id_rekam;
$this->params['breadcrumbs'][] = ['label' => 'Rekams', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id_rekam, 'url' => ['view', 'id_rekam' => $model->id_rekam]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="rekam-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
