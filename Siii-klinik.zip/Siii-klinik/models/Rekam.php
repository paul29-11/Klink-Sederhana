<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "rekam".
 *
 * @property int $id_rekam
 * @property string $tgl
 * @property int $id_pasien
 * @property string $keluahan
 * @property int $id_dokter
 * @property string $diagnosa
 * @property int $id_obat
 * @property int $id_ruang
 *
 * @property Dokter $dokter
 * @property Obat $obat
 * @property Pasien $pasien
 * @property Ruang $ruang
 */
class Rekam extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'rekam';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['tgl', 'id_pasien', 'keluahan', 'id_dokter', 'diagnosa', 'id_obat', 'id_ruang'], 'required'],
            [['id_pasien', 'id_dokter', 'id_obat', 'id_ruang'], 'integer'],
            [['tgl'], 'string', 'max' => 30],
            [['keluahan'], 'string', 'max' => 100],
            [['diagnosa'], 'string', 'max' => 250],
            [['id_pasien'], 'exist', 'skipOnError' => true, 'targetClass' => Pasien::class, 'targetAttribute' => ['id_pasien' => 'id_pasien']],
            [['id_dokter'], 'exist', 'skipOnError' => true, 'targetClass' => Dokter::class, 'targetAttribute' => ['id_dokter' => 'id_dokter']],
            [['id_obat'], 'exist', 'skipOnError' => true, 'targetClass' => Obat::class, 'targetAttribute' => ['id_obat' => 'id_obat']],
            [['id_ruang'], 'exist', 'skipOnError' => true, 'targetClass' => Ruang::class, 'targetAttribute' => ['id_ruang' => 'id_ruang']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_rekam' => 'Id Rekam',
            'tgl' => 'Tgl',
            'id_pasien' => 'Id Pasien',
            'keluahan' => 'Keluahan',
            'id_dokter' => 'Id Dokter',
            'diagnosa' => 'Diagnosa',
            'id_obat' => 'Id Obat',
            'id_ruang' => 'Id Ruang',
        ];
    }

    /**
     * Gets query for [[Dokter]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDokter()
    {
        return $this->hasOne(Dokter::class, ['id_dokter' => 'id_dokter']);
    }

    /**
     * Gets query for [[Obat]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getObat()
    {
        return $this->hasOne(Obat::class, ['id_obat' => 'id_obat']);
    }

    /**
     * Gets query for [[Pasien]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPasien()
    {
        return $this->hasOne(Pasien::class, ['id_pasien' => 'id_pasien']);
    }

    /**
     * Gets query for [[Ruang]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRuang()
    {
        return $this->hasOne(Ruang::class, ['id_ruang' => 'id_ruang']);
    }
}
