<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pasien".
 *
 * @property int $id_pasien
 * @property string $nama
 * @property string $jk
 * @property string $alamat
 * @property string $hp
 *
 * @property Rekam[] $rekams
 */
class Pasien extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'pasien';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama', 'jk', 'alamat', 'hp'], 'required'],
            [['alamat'], 'string'],
            [['nama', 'jk'], 'string', 'max' => 100],
            [['hp'], 'string', 'max' => 15],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_pasien' => 'Id Pasien',
            'nama' => 'Nama',
            'jk' => 'Jk',
            'alamat' => 'Alamat',
            'hp' => 'Hp',
        ];
    }

    /**
     * Gets query for [[Rekams]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRekams()
    {
        return $this->hasMany(Rekam::class, ['id_pasien' => 'id_pasien']);
    }
}
