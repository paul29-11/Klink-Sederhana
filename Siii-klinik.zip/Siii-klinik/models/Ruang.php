<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "ruang".
 *
 * @property int $id_ruang
 * @property string $nama
 * @property string $ket
 *
 * @property Rekam[] $rekams
 */
class Ruang extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'ruang';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama', 'ket'], 'required'],
            [['ket'], 'string'],
            [['nama'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_ruang' => 'Id Ruang',
            'nama' => 'Nama',
            'ket' => 'Ket',
        ];
    }

    /**
     * Gets query for [[Rekams]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRekams()
    {
        return $this->hasMany(Rekam::class, ['id_ruang' => 'id_ruang']);
    }
}
