<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "obat".
 *
 * @property int $id_obat
 * @property string $nama
 * @property string $ket
 *
 * @property Rekam[] $rekams
 */
class Obat extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'obat';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama', 'ket'], 'required'],
            [['ket'], 'string'],
            [['nama'], 'string', 'max' => 100],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_obat' => 'Id Obat',
            'nama' => 'Nama',
            'ket' => 'Ket',
        ];
    }

    /**
     * Gets query for [[Rekams]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRekams()
    {
        return $this->hasMany(Rekam::class, ['id_obat' => 'id_obat']);
    }
}
