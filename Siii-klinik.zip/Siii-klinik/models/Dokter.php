<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "dokter".
 *
 * @property int $id_dokter
 * @property string $nama
 * @property string $spesialis
 * @property string $alamat
 * @property string $hp
 *
 * @property Rekam[] $rekams
 */
class Dokter extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'dokter';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nama', 'spesialis', 'alamat', 'hp'], 'required'],
            [['alamat'], 'string'],
            [['nama', 'spesialis'], 'string', 'max' => 100],
            [['hp'], 'string', 'max' => 15],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id_dokter' => 'Id Dokter',
            'nama' => 'Nama',
            'spesialis' => 'Spesialis',
            'alamat' => 'Alamat',
            'hp' => 'Hp',
        ];
    }

    /**
     * Gets query for [[Rekams]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getRekams()
    {
        return $this->hasMany(Rekam::class, ['id_dokter' => 'id_dokter']);
    }
}
